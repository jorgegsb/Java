package examenporobjetos;

import java.util.Scanner;

public class ExamenPorObjetos {

    static Partido[] compe = new Partido[3];
   

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        //array de partidos tiene que pedir cuantos partidos tiene la competicion
        Partido resultado = new Partido();
        for (int i = 0; i < 3; i++) {

            compe[i] = new Partido();

        }

        for (int i = 0; i < 3; i++) {
            int r1, r2;

            System.out.println("introduce resultado 1º equipo: " + i);
            r1 = teclado.nextInt();
            System.out.println("introduce resultado 2º equipo: " + i);
            r2 = teclado.nextInt();
            compe[i].setResultado(r1, r2);

        }

        for (int i = 0; i < 3; i++) {

            System.out.print(compe[i].getEquipoCasa().getNombre() + " ");
            System.out.print(compe[i].getEquipoVisitante().getNombre());
            System.out.println(" " + compe[i].compararResultado());
            System.out.println(" el maximo es: "+compe[i].maximo());
            System.out.println(compe[i].goleador());

        }

    }

    
}
