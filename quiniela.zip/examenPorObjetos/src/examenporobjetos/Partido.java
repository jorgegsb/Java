package examenporobjetos;

import static examenporobjetos.ExamenPorObjetos.compe;
import java.util.Scanner;

class Partido {

    private Equipo equipoCasa;
    private Equipo equipoVisitante;
    private int[] resultado = new int[2];
    private Equipo Max;

    public Equipo getEquipoCasa() {
        return equipoCasa;
    }

    public Equipo getEquipoVisitante() {
        return equipoVisitante;
    }

    public int[] getResultado() {
        return resultado;
    }

    public Partido() {
        Scanner teclado = new Scanner(System.in);
        System.out.print("Leer Id primer equipo: ");
        int id = teclado.nextInt();
        this.equipoCasa = new Equipo(id, "Equipo" + id);
        System.out.print("Leer Id segundo equipo: ");
        id = teclado.nextInt();
        this.equipoVisitante = new Equipo(id, "equipo" + id);

    }

    public void setResultado(int r1, int r2) {
        this.resultado[0] = r1;
        this.resultado[1] = r2;
    }
    public char compararResultado(){
        char res;
        if (this.resultado[0]==this.resultado[1]){
           res='X';
        }
        
        else if(this.resultado[0]>this.resultado[1]){
        res='1';
        
        
        
        }
        
        else{
        res='2';
        }
        
        return res;
    }
    public int maximo() {
     
        int max = -1;
        
   

            if (this.resultado[0]> max) {

                max =this.resultado[0];
                
                
            }
             if( this.resultado[1]>max) {

                max = this.resultado[1];

            }

       

        return max;
    }
    
    public String goleador(){
    
    if(this.resultado[0]>this.resultado[1]){
    
    return "el goleador es el equipo1";
    
    
    }
        if(this.resultado[1]>this.resultado[0]){
        
        return"el goleador es el equipo2";
        
        }
       
        return "empate en goles";
    }

}
