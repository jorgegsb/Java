package tres.en.raya.por.mi;

import java.util.Scanner;

public class TresEnRayaPorMi {

    static Scanner teclado = new Scanner(System.in);
    static char[][] tablero = new char[3][3];
    static int turno = 1;
    static char fig;

    public static void main(String[] args) {
        crearTablero();
        visualizar();
    }
//creamos el tablero introduciendo en el array tablero guiones, con un bucle for se van guardando en cada cajón del for 
    public static void crearTablero() {

        for (int i = 0; i < 3; i++) {

            for (int j = 0; j < 3; j++) {

                tablero[i][j] = '-';
            }

        }

    }
    
  /*en esta funcion, visualizamos el tablero al completo: el primer sout es para visualizar las columnas del tablero
    el primer for empieza imprimendo sin saltar la línea los digitos de la fila y haciendo un espacio, esto se repite cada vez
    que acaba el segundo for, el segundo for se encarga de imprimir el tablero y hacer espacios entre los guiones
    importante el print sin ln por que si no va a dar salto de linea y van a parecer todos los guiones en columna 
    al acabar el segundo for volvemos al primer for, creamos un salto de línea para que los guiones salgan en distintas filas
    */  
    public static void visualizar(){
        System.out.println("    0  1  2");
        
        for(int i=0;i<3;i++){
            System.out.print(i+" ");
           
     
            for(int j=0;j<3;j++){
            
                System.out.print("  " +tablero[i][j] );
            
            
            }
             System.out.println(" ");
           }
        
    }
    /*lo primero crear una variable boolean e inicalizarla a falso, esta variable va a indicar que al recorrer
    el tablero si no se cumple que hayan '-' en todo el tablero al acabar el bucle va a ser true y al ser true retorna dicho valor
    y al no haber '-' significa que hay un empate dado que no quedan mas huecos por rellenar y no se ha ganado dado que no ha 
    saltado la función ganar*/
    public static boolean lleno(){
    
    boolean aux=false;    
    for(int i=0;(aux==false)&&(i<3);i++){
       int j;
       for(j=0;(aux==false)&&(i<3)&&(j<3);j++){
       
           aux=(tablero[i][j]=='-');
       
       }
     
        
        
    }
    return !aux;
    }
    /*aqui establecemos la función cambio de turno, la creamos para que devuelva un int y se introduzca el parametro turno para decicidir a quien le toca poner la ficha
    si el turno inicial introducido es 1 le toca a x si no le toca a O*/
    static int cambiarturno(int turno) {

        if (turno == 1) {
            
            turno = 2; fig='x';

        } else {
            turno = 1;fig='0';
        }

        return turno;

    }
    
    /*en esta funcion estamos determinando en que lugar se va a colocar el turno, mientras que el en la posición seleccionada  haya '-' se va a poder colocar
    el signo del turno correspondiente si lo hay o no corresponden las filas y las columnas a las filas y columnas posibles dentro del tablero va a continuar el bucle do-while
        por tanto si se cumplen todas estas condiciones va a poder realizarse el turno perfectamente*/
    static void elegirpos(){
    int fila, columna;
    do{
        do{
            System.out.println("¿En qué fila quieres poner tu ficha?");
            fila = teclado.nextInt();
        }while ((fila <-1) || (fila>4));
        do{
            System.out.println("¿En qué columna quieres poner tu ficha?");
            columna = teclado.nextInt();
        }while ((columna<-1) || (columna>4));
        
    
    }while (tablero[fila][columna]!='-');
    
    tablero[fila][columna]=fig;
    }
    
    /*en la función ganar lo que estamos haciendo es determinar cuando gana el jugador.
     lo primero declaramos e inicializamos a 0 i, esto de lo que se va a encargar es que cuando este dentro del bucle
    va ir recorriendo las filas y columnas dependiendo de lo que busques , en el primer if recorre columnas,el segundo filas.
    la segunda variable es un boolean, en el boolean se incializa a falso para que cuando se cumpla la condicion, sea true, salga
    del bucle y y retorne el valor verdadero si se cumple cualquier if significa que has ganado no importa que Seas X o O
    en ambas situaciones vas a ganar.
    saldras del bucle cuando la condicion sea true y te dira: jugador (quien sea) has ganado la partida por eso dentro de la condicion de los if se iguala a fig lo que haya en tablero
    para que si se cumple que las tres posiciones sean iguales ganas la partida*/
    public static boolean ganar(){
        int i=0;
        boolean aux=false;
        while(i<3 && !aux){
        
            if(tablero[i][0]==fig && tablero[i][1]==fig && tablero[i][2]==fig){
                aux=true;
            }
            if(tablero[0][i]==fig && tablero[1][i]==fig && tablero[2][i]==fig){
                aux=true;
            }
            if(tablero[0][0]==fig && tablero[1][1]==fig && tablero[2][2]==fig){
                aux=true;
            }
            if(tablero[2][0]==fig && tablero[1][1]==fig && tablero[0][2]==fig){
                aux=true;
            }
          i++;    
        }
          return aux;
    }
}
